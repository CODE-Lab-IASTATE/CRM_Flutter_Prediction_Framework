              QUICK START GUIDE - Linux 64 bit, Version 6.12
              ----------------------------------------------

The files that were in file MYSTRAN_Linux_files.tar that was downloaded from
the MYSTRAN web site should have included:

     1) README.TXT: this file, which is a text file containing basic
        information on how to quickly install and get up and running MYSTRAN

     2) mystran.exe: the executable that runs the MYSTRAN program

     3) Script file "set_MYSTRAN_directory.sh"

     4) MYSTRAN.INI: a MYSTRAN initialization file (discussed in the
        MYSTRAN-Install-Man.PDF file).

     5) EXAMPLE1.DAT: the input data deck for the example problem 
        explained in the MYSTRAN Users Reference Manual Appendix A

     6) EXAMPLE1.F06-archive: the output data for the example problem,
        also contained in the MYSTRAN Users Reference Manual Appendix A 

     7) MYSTRAN-Pricing.pdf: the cost for various options of the unlimited
        problem size edition of MYSTRAN

     8) MYSTRAN-Users-Manual.pdf: the MYSTRAN User�s Reference Manual

     9) MYSTRAN-Install-Manual.pdf: a detailed installation and run manual.
        Read this to learn how to run problems that have no programmatic
        restrictions on problem size.

    10) MYSTRAN-Demo-Problem-Manual.pdf 

    11) Errors corrected.pdf: A list of the errors corrected in the current
        version

    12) New features.pdf: New features that have been added to MYSTRAN

    13) A subdirectory with several MYSTRAN sample problem runs (run on
        the Windows version of MYSTRAN)

The files with an extension with pdf are in Adobe PDF format and can be
read, and printed, using Adobe Acrobat Reader; a free download available from 
the Adobe internet site at www.adobe.com.

After unzipping the tar file, and making sure that mystran.exe, mystran.ini
and the example problem DAT file are all in the same folder, the easiest way
to run the program is to open a terminal and give the command:

                   mystran.exe EXAMPLE1

The output file (EXAMPLE1.F06) for the example problem will be found in the 
same directory in which the files were put during installation

In addition to the F06 file there may be several other files created
during the execution depending on the settings in the INI and DAT files.

If you want to have your input files in a different folder you should read 
the Installation and Run Manual (file MYSTRAN-Install-Manual.pdf).
