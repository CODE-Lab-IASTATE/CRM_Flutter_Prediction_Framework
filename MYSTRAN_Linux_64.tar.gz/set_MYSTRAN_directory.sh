if [ -z "${MYSTRAN_directory}"]
then
MYSTRAN_directory="/home/bc/MYSTRAN/bin"; export MYSTRAN_directory
else
MYSTRAN_directory="/home/bc/MYSTRAN/bin:${MYSTRAN_directory}"; export MYSTRAN_directory
fi
